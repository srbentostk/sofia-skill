# Aprender Estilo de Escrita

## Quando oferecer

Na primeira interação com um novo usuário, ou quando ainda não existe arquivo de estilo salvo, ofereça:

> "Antes de escrever, quer que eu aprenda seu estilo? Se você me mandar alguns dos seus melhores roteiros, eu aprendo seu tom, suas palavras, seu ritmo — e escrevo do seu jeito. Leva uns minutos, mas depois todo roteiro sai com a sua cara."
>
> "Você escreve sempre pro mesmo perfil ou tem clientes diferentes com estilos diferentes?"

## Fluxo se escreve pra UM perfil

1. Peça 3-5 roteiros que a pessoa considera bons
2. Analise e salve UM arquivo de estilo
3. Use sempre esse estilo ao escrever

> "Me manda de 3 a 5 roteiros seus que você gosta. Pode colar aqui ou mandar arquivo. Vou digerir e aprender seu jeito de escrever."

## Fluxo se escreve pra CLIENTES diferentes

1. Pergunte quais clientes/perfis existem
2. Peça roteiros de cada cliente separado
3. Salve UM arquivo de estilo POR cliente
4. Antes de escrever, pergunte qual cliente (se não estiver claro)

> "Quais são seus clientes ou perfis? Me conta os nomes que depois a gente organiza os estilos separados."
>
> (depois) "Agora manda uns 3-5 roteiros do [cliente]. Vou aprender o estilo dele separado."

## Como digerir os roteiros

Ao receber os roteiros, analise e extraia:

### 1. Tom geral
- É mais sério ou mais descontraído?
- Fala na primeira pessoa (eu) ou terceira (ele/ela)?
- É direto ou constrói contexto antes?
- Usa humor? Ironia? Provocação?

### 2. Ritmo das frases
- Frases são curtas ou longas? Qual o tamanho médio?
- Alterna curtas com longas ou mantém padrão?
- Usa frases incompletas? Fragmentos?
- Como faz pausas e transições?

### 3. Palavras e expressões recorrentes
- Quais palavras aparecem em mais de um roteiro?
- Tem expressões que são "a cara" dessa pessoa?
- Tem gírias ou regionalismos?
- Como se dirige ao público? (você, tu, vocês, pessoal, galera)

### 4. Tipo de abertura
- Como costuma abrir? Pergunta? Afirmação forte? Dado?
- Entra direto no assunto ou prepara terreno?
- Usa referência conhecida pra abrir?

### 5. Estrutura preferida
- Como organiza o roteiro? Começo-meio-fim linear? Vai e volta?
- Quanto tempo gasta na abertura vs. desenvolvimento vs. fechamento?
- Usa listas? Exemplos? Histórias?

### 6. Fechamento
- Como termina? Com lição? Pergunta? Call to action?
- O final é emocional ou prático?

### 7. O que NÃO faz (tão importante quanto o que faz)
- Que tipo de frase nunca usa?
- Que tom nunca adota?
- Tem algum padrão que evita?

## Salvar o estilo

Depois de analisar, crie o arquivo de estilo em `${CLAUDE_SKILL_DIR}/estilos/`:

- Se é perfil único: `${CLAUDE_SKILL_DIR}/estilos/meu-estilo.md`
- Se é por cliente: `${CLAUDE_SKILL_DIR}/estilos/[nome-do-cliente].md`

**Formato do arquivo de estilo:**

```markdown
# Estilo: [nome do perfil ou cliente]

## Tom
[descrição em 2-3 frases]

## Ritmo
- Tamanho médio das frases: [curtas/médias/longas]
- Padrão: [ex: alterna curtas com uma longa]
- Usa fragmentos: [sim/não]

## Palavras e expressões recorrentes
- [lista das palavras/expressões que mais usa]

## Como se dirige ao público
[ex: "você", sempre informal, nunca "vocês"]

## Tipo de abertura preferida
[ex: pergunta provocativa, dado surpreendente]

## Estrutura preferida
[ex: abre com conflito, desenvolve com exemplos, fecha com lição]

## Fechamento típico
[ex: pergunta reflexiva, sem CTA explícito]

## O que NUNCA faz
- [lista do que evitar nesse estilo]

## Frases de referência
[3-5 frases dos roteiros que representam bem o estilo — pra consulta, não pra copiar]
```

Depois de salvar, confirme:

> "Pronto, aprendi seu estilo. Salvei aqui e vou usar nos próximos roteiros. Quer que eu escreva algo agora?"

Se for por cliente:
> "Salvei o estilo do [cliente]. Quando for escrever pra ele, vou usar essa base. Quer mandar roteiros de outro cliente agora?"

## Usar o estilo ao escrever

Antes de escrever qualquer roteiro, verifique se existe arquivo de estilo:

1. Se existe UM estilo (`estilos/meu-estilo.md`): use automaticamente
2. Se existem VÁRIOS estilos: pergunte "Esse roteiro é pra qual perfil? [lista os nomes]"
3. Se não existe nenhum: ofereça aprender (ver início deste arquivo)

Ao escrever, o estilo aprendido tem PRIORIDADE sobre as regras genéricas de tom. Se o estilo do usuário usa frases mais longas que o padrão, respeite. Se usa palavras que normalmente seriam "proibidas", respeite — é o estilo dele.

**A única exceção:** nunca viole as regras de nunca inventar e nunca plagiar, independente do estilo.
