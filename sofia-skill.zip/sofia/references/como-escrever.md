# Como Escrever — Padrões Extraídos de Bons Roteiros

Este arquivo é referência interna. NUNCA copie frases daqui. Aprenda os PADRÕES e escreva texto novo.

## 1. ESPECIFICIDADE MATA GENERALIDADE

Bons roteiros usam detalhes concretos, não descrições genéricas.

**O padrão:**
- Nome próprio > categoria ("Frank Ocean" > "um artista famoso")
- Número exato > "muitas vezes" ("600 vezes" > "diversas vezes")
- Detalhe absurdo > explicação ("tia de segundo grau" > "uma parente")
- Cena descrita > sentimento narrado ("acordou cedo mesmo cansado só pra te levar" > "era dedicado")

**Por que funciona:** o cérebro não consegue imaginar "uma pessoa famosa". Consegue imaginar Frank Ocean. Imagem mental = retenção.

**Na prática, quando escrever:**
- Troque todo adjetivo genérico por uma cena concreta
- Se falou "muitos", coloque o número
- Se falou "alguém famoso", coloque o nome
- Se falou "um sentimento ruim", descreva a cena que gera o sentimento

## 2. "MAS" COMO MOTOR DE CONTRASTE

O "mas" é a ferramenta mais usada em bons roteiros pra virar o sentido da frase.

**O padrão:**
- Construção positiva + "mas" + inversão
- Construção negativa + "mas" + surpresa
- Afirmação do público + "mas" + contradição

**Na prática:**
- "Fatura 9 bilhões, mas naquela época não era nada"
- "Você nunca ouviu falar, mas eles são referência pra milhares"
- "Você entrega valor, mas fica esperando reconhecimento"

Cada "mas" é uma mini-virada. Acumular viradas = manter atenção.

## 3. FRASES CURTAS COM SOCO

Bons roteiros alternam frases longas com frases que param tudo.

**O padrão:**
- Frase que constrói contexto (mais longa)
- Frase que entrega o impacto (curta, seca)

**Exemplos do padrão (NÃO copie, entenda o ritmo):**
- Contexto longo → "Nada." (1 palavra)
- Contexto longo → "O problema?" (2 palavras)
- Contexto longo → "Do artista que eu não fui." (fragmento com peso)

**Na prática:**
- Depois de construir uma ideia em 2-3 frases, entregue o impacto em UMA frase curta
- A frase curta pode ser: pergunta, fragmento, contradição, revelação
- Não tenha medo de frases de 2-3 palavras. Elas carregam o peso.

## 4. PERGUNTAS QUE FORÇAM IMAGENS MENTAIS

Começar com "Sabe aquela pessoa que..." faz o público lembrar de alguém específico. Ele não ouve uma descrição — ele vê um rosto.

**O padrão:**
- "Sabe aquela pessoa que [descrição específica de comportamento]?"
- "Imagina a seguinte cena."
- "Para e pensa: [conexão com a vida do público]"

**Por que funciona:** o público para de assistir passivamente e começa a processar. Debate mental ativo = retenção.

**Na prática:**
- Use "sabe aquela pessoa/situação" pra ativar memória
- Use "imagina" pra criar cena mental
- Use "para e pensa" pra forçar reflexão
- Descreva comportamento, não personalidade ("super educada na frente, contamina o time por trás" > "pessoa falsa")

## 5. FECHAMENTO CASUAL DEPOIS DE PESO

Quanto mais elaborada a história, mais casual deve ser o fechamento.

**O padrão:**
- História complexa e emocional → frase final despretensiosa
- Construção absurda → "enfim, foi assim que [coisa simples]"
- Vulnerabilidade → autodepreciação leve

**Por que funciona:** o contraste entre o peso do conteúdo e a leveza do final gera humor, alívio e identificação. A pessoa ri e compartilha.

**Na prática:**
- Se construiu algo grande, não feche com mais grandeza
- Feche como alguém que conta história no bar: "e foi isso"
- Autodepreciação funciona se veio depois de confiança (contraste)

## 6. ESCALADA PROGRESSIVA

Cada frase aumenta a aposta da anterior. O público sente que a coisa tá crescendo.

**O padrão:**
- Fato → consequência → consequência maior → pico
- Cada beat é um degrau acima do anterior
- Nunca repete o mesmo nível de intensidade

**Na prática:**
- Se a primeira frase é "ele mentiu", a próxima não pode ser "ele enganou" (mesmo nível)
- A próxima tem que ser "e a mentira virou uma marca de 9 bilhões" (degrau acima)
- Se duas frases seguidas têm o mesmo peso, corte uma

## 7. CONECTAR HISTÓRIA DISTANTE COM VIDA DO PÚBLICO

Toda história sobre outra pessoa precisa virar espelho.

**O padrão:**
- Conta história de terceiro (famoso, personagem, caso real)
- No momento certo, vira a câmera pro público: "e você?"
- Mostra que a vida do público tem o mesmo padrão

**Na prática:**
- Nunca termine uma história sem trazê-la pra realidade do público
- Use "e você" ou "a verdade é que" como ponte
- O público não quer saber do Tommy Hilfiger, quer saber dele mesmo
- A história é o veículo. A moral aplicada à vida do público é o destino.

## 8. CONTRADIÇÃO COMO ABERTURA

Duas informações que não fecham juntas forçam o cérebro a continuar.

**O padrão:**
- Frase A afirma algo
- Frase B contradiz A
- O público precisa resolver → fica assistindo

**Na prática:**
- "Terapia de casal. Sem ser um casal de verdade." (contradição direta)
- "Empresário mentiroso que faturou bilhões." (mentira + sucesso = não fecha)
- "Não quero ser visto. Sou muito exibido." (contradição de personalidade)

A contradição funciona melhor quando as duas partes são curtas e coladas. Quanto menos palavras entre A e B, maior o impacto.

## 9. LINGUAGEM REAL

Bons roteiros usam as palavras que as pessoas usam.

**O padrão:**
- Palavras do cotidiano, mesmo as "feias"
- Gírias que o público reconhece
- Termos que a pessoa usaria contando a história num bar

**Na prática:**
- "Quem diabos é esse?" > "Quem seria esse indivíduo?"
- "Ir pra cima" > "confrontar agressivamente"
- "Dar a cagada e ter a ideia da minha vida" > "utilizar o banheiro e ter uma epifania"
- Se a palavra "certa" soa como redação, é a palavra errada

## 10. CTA QUE FAZ SENTIDO

O pedido no final só funciona se é coerente com tudo que veio antes.

**O padrão:**
- CTA que é extensão natural do conteúdo
- Reciprocidade: pede algo simples, oferece algo em troca
- Ou: nenhum CTA (o conteúdo é o valor)

**Na prática:**
- Se o vídeo é sobre ser autêntico, o CTA é "me segue porque eu falo do que eu gosto" (coerente)
- Se o vídeo ensinou algo, o CTA é "digita X que eu mando Y" (reciprocidade)
- Nunca: "curte e compartilha" genérico. Sempre conecte com o tema.

## REGRA DE OURO

**Copie a emoção e a lógica. Nunca copie as palavras.**

Esses padrões são esqueletos. A carne tem que ser nova — do assunto do usuário, do público dele, das histórias reais que ele trouxer.
